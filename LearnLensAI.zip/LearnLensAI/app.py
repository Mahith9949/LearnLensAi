import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB uploads

API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=API_KEY) if API_KEY else None
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM_INSTRUCTIONS = """
You are LearnLens AI, a supportive educational tutor.
Help students understand mistakes rather than just giving answers.
When given a question, written solution, or educational image:
1. Identify what the student appears to be trying to solve.
2. Explain any likely mistake carefully. If the work is unclear, say so instead of guessing.
3. Show a correct approach step by step.
4. Give one short practice question with an answer hidden under a separate heading.
Be kind, age-appropriate, concise, and educational. Do not claim certainty if the image is blurry.
Use Markdown. For math, use readable LaTeX where helpful.
"""

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/analyze")
def analyze():
    if not client:
        return jsonify({
            "error": "Gemini API key is missing. Create a .env file and set GEMINI_API_KEY=your_key."
        }), 503

    question = (request.form.get("question") or "").strip()
    image_file = request.files.get("image")

    if not question and (not image_file or not image_file.filename):
        return jsonify({"error": "Enter a question or upload an image of your work."}), 400

    parts = [types.Part.from_text(text=SYSTEM_INSTRUCTIONS + "\n\nStudent's question/context:\n" + (question or "Please analyze the uploaded work."))]

    if image_file and image_file.filename:
        allowed = {"png", "jpg", "jpeg", "webp"}
        ext = image_file.filename.rsplit(".", 1)[-1].lower() if "." in image_file.filename else ""
        if ext not in allowed:
            return jsonify({"error": "Please upload a PNG, JPG, JPEG, or WEBP image."}), 400
        data = image_file.read()
        if not data:
            return jsonify({"error": "The uploaded image is empty."}), 400
        mime = image_file.mimetype or "image/jpeg"
        parts.append(types.Part.from_bytes(data=data, mime_type=mime))

    try:
        response = client.models.generate_content(
            model=MODEL,
            contents=[types.Content(role="user", parts=parts)]
        )
        answer = response.text or "I couldn't generate an explanation. Please try again with a clearer question or image."
        return jsonify({"answer": answer})
    except Exception as exc:
        # Keep detailed errors in server logs; return a useful message to the browser.
        app.logger.exception("Gemini request failed")
        return jsonify({"error": "AI analysis failed. Check your API key, internet connection, model access, and server terminal for details."}), 502

@app.get("/health")
def health():
    return jsonify({"status": "ok", "model": MODEL, "api_key_configured": bool(API_KEY)})

if __name__ == "__main__":
    app.run(debug=True, port=int(os.getenv("PORT", "5000")))
