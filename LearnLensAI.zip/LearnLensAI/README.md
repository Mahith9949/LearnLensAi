# LearnLens AI

A runnable multimodal learning-tutor prototype. It accepts a typed question and/or an image of handwritten work, sends it to Gemini, and displays an explanation and a follow-up practice question.

## Requirements
- Python 3.10+
- A Gemini API key from Google AI Studio
- Internet connection for AI requests

## Run in VS Code

### 1. Open the project folder
Extract `LearnLensAI.zip`, then open the `LearnLensAI` folder in VS Code.

### 2. Create and activate a virtual environment

Windows PowerShell:
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install packages
```bash
pip install -r requirements.txt
```

### 4. Add your API key
Copy `.env.example` to a new file named `.env`, then replace the placeholder with your own Gemini API key:
```env
GEMINI_API_KEY=your_real_api_key_here
GEMINI_MODEL=gemini-2.5-flash
PORT=5000
```
Never share your `.env` file or commit it to GitHub.

### 5. Start the app
```bash
python app.py
```
Open http://127.0.0.1:5000 in your browser.

## What works
- Typed questions
- Image upload for handwritten work or diagrams
- AI-generated explanation and practice question
- Friendly responsive interface
- Upload validation and helpful error messages

## Current prototype limitations
- Speech input and saved student progress are not implemented yet.
- AI output can be incorrect; verify important answers.
- A valid API key and model access are required for live AI analysis.
